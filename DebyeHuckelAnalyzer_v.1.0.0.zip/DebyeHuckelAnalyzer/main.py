# -*- coding: utf-8 -*-

import sys
import os
from io import BytesIO
import numpy as np

# === Исправление для всех версий matplotlib и PySide6 ===
import matplotlib
matplotlib.use('QtAgg')  # Вместо 'Qt5Agg' — автоматический выбор Qt5/Qt6

# Принудительно указываем бэкенд через переменные окружения
os.environ.setdefault('QT_API', 'PySide6')

# Импорт FigureCanvas с обработкой обоих вариантов
try:
    # Пробуем новый путь (matplotlib >= 3.8)
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
except ImportError:
    # Запасной путь (matplotlib < 3.8)
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from matplotlib.figure import Figure
import matplotlib.pyplot as plt

# Импорты для GUI
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QLineEdit, QPushButton, QGroupBox, QRadioButton,
    QFileDialog, QMessageBox, QMenuBar, QMenu, QStatusBar, QButtonGroup
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon, QAction, QFont

# Для PDF-экспорта
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm, cm

# ============================================================
# 1. СЛОЙ ФИЗИЧЕСКОЙ МОДЕЛИ (Model)
# ============================================================
class DebyeHuckelModel:
    """
    Реализует три приближения теории Дебая-Хюккеля.
    Все расчеты ведутся в логарифмической шкале (lg gamma).
    Векторизованные методы: корректно работают как со скалярами, 
    так и с массивами NumPy.
    """
    
    # Константы для воды при 25°C
    A = 0.509  # л^(1/2)/моль^(1/2)
    B = 0.329  # Å^(-1) * л^(1/2)/моль^(1/2)
    
    @staticmethod
    def ionic_strength(z_cation, z_anion, concentration):
        """
        Расчет ионной силы I для электролита M_v1 X_v2.
        Пример: CaCl2 (z+ = 2, z- = -1, c = 0.1)
        nu_+ = 1, nu_- = 2 => I = 0.5 * (1*c*4 + 2*c*1) = 0.5 * 6c = 3c
        """
        z_c = abs(z_cation)
        z_a = abs(z_anion)
        gcd = np.gcd(z_c, z_a)
        nu_c = z_a // gcd  # стехиометрический коэффициент катиона
        nu_a = z_c // gcd  # стехиометрический коэффициент аниона
        
        m_c = nu_c * concentration
        m_a = nu_a * concentration
        
        I = 0.5 * (m_c * z_c**2 + m_a * z_a**2)
        return I

    @staticmethod
    def first_approx(z_cation, z_anion, I):
        """
        Предельный закон: lg γ± = -A * |z+ * z-| * sqrt(I)
        
        Параметры
        ----------
        I : float или numpy.ndarray
            Ионная сила (или массив значений).
        
        Возвращает
        -------
        float или numpy.ndarray
            lg(γ±). Для I <= 0 возвращается 0.0.
        """
        I = np.asarray(I, dtype=float)         # приводим к массиву для единообразия
        result = np.zeros_like(I)              # массив (или скаляр) из нулей
        mask = I > 0                           # маска: где I положительно
        sqrt_I = np.sqrt(I, where=mask, out=np.zeros_like(I))
        result[mask] = -DebyeHuckelModel.A * abs(z_cation * z_anion) * sqrt_I[mask]
        # если I — скаляр, вернётся скаляр; если массив — массив
        return result if isinstance(I, np.ndarray) else float(result)

    @staticmethod
    def second_approx(z_cation, z_anion, I, a):
        """
        Расширенный закон: lg γ± = -A|z+z-|√I / (1 + Ba√I)
        
        Параметры
        ----------
        I : float или numpy.ndarray
            Ионная сила (или массив значений).
        a : float
            Эффективный диаметр, Å.
        """
        I = np.asarray(I, dtype=float)
        result = np.zeros_like(I)
        mask = I > 0
        sqrt_I = np.sqrt(I, where=mask, out=np.zeros_like(I))
        numerator = DebyeHuckelModel.A * abs(z_cation * z_anion) * sqrt_I[mask]
        denominator = 1 + DebyeHuckelModel.B * a * sqrt_I[mask]
        result[mask] = -numerator / denominator
        return result if isinstance(I, np.ndarray) else float(result)

    @staticmethod
    def third_approx(z_cation, z_anion, I, a, C):
        """
        Уравнение с линейным членом: lg γ± = -A|z+z-|√I / (1 + Ba√I) + CI
        
        Параметры
        ----------
        I : float или numpy.ndarray
            Ионная сила (или массив значений).
        a : float
            Эффективный диаметр, Å.
        C : float
            Эмпирический коэффициент.
        """
        I = np.asarray(I, dtype=float)
        result = np.zeros_like(I)
        mask = I > 0
        sqrt_I = np.sqrt(I, where=mask, out=np.zeros_like(I))
        numerator = DebyeHuckelModel.A * abs(z_cation * z_anion) * sqrt_I[mask]
        denominator = 1 + DebyeHuckelModel.B * a * sqrt_I[mask]
        base = -numerator / denominator
        result[mask] = base + C * I[mask]
        return result if isinstance(I, np.ndarray) else float(result)

# ============================================================
# 2. КЛАСС ДЛЯ ПОСТРОЕНИЯ ГРАФИКОВ (Canvas)
# ============================================================
class MplCanvas(FigureCanvas):
    """Холст matplotlib для встраивания в PySide6."""
    def __init__(self, parent=None, width=8, height=6, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

        # Настройка сетки и подписей
        self.axes.set_xlabel("√I (моль/л)^(1/2)")
        self.axes.set_ylabel("lg(γ±)")
        self.axes.grid(True, linestyle='--', alpha=0.7)
        self.axes.set_title("Приближения теории Дебая-Хюккеля")
        self.fig.tight_layout()

# ============================================================
# 3. ГЛАВНОЕ ОКНО (MainWindow)
# ============================================================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Debye-Huckel Analyzer v.1.0")
        self.setGeometry(100, 100, 1200, 700)

        # Установка иконки (если есть файл)
        self.setup_icon()

        # Данные эксперимента (для точечного графика)
        self.exp_x = None
        self.exp_y = None

        # Настройка меню
        self.setup_menu()

        # Настройка UI
        self.setup_ui()

        # Статус-бар
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Готов к работе. Введите параметры электролита.")

        # Начальная прорисовка пустого графика
        self.canvas.axes.clear()
        self.canvas.axes.set_xlabel("√I (моль/л)^(1/2)")
        self.canvas.axes.set_ylabel("lg(γ±)")
        self.canvas.axes.grid(True, linestyle='--', alpha=0.7)
        self.canvas.draw()

    def setup_icon(self):
        try:
            # Пытаемся загрузить иконку из файла
            base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
            icon_path = os.path.join(base_path, "icon.png")
            if os.path.exists(icon_path):
                self.setWindowIcon(QIcon(icon_path))
        except:
            pass

    def setup_menu(self):
        """Создание строки меню"""
        menubar = self.menuBar()

        # Файл
        file_menu = menubar.addMenu("Файл")

        load_action = QAction("Загрузить эксперимент (.csv)", self)
        load_action.triggered.connect(self.load_csv)
        file_menu.addAction(load_action)

        save_png_action = QAction("Экспорт графика (PNG)", self)
        save_png_action.triggered.connect(self.save_png)
        file_menu.addAction(save_png_action)

        save_csv_action = QAction("Экспорт результатов (CSV)", self)
        save_csv_action.triggered.connect(self.save_csv)
        file_menu.addAction(save_csv_action)

        save_pdf_action = QAction("Экспорт отчета (PDF)", self)
        save_pdf_action.triggered.connect(self.save_pdf)
        file_menu.addAction(save_pdf_action)

        file_menu.addSeparator()

        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Справка
        help_menu = menubar.addMenu("Справка")
        about_action = QAction("О программе", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def setup_ui(self):
        """Построение интерфейса: панель управления слева, график справа."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)

        # ==================== ЛЕВАЯ ПАНЕЛЬ ====================
        left_panel = QWidget()
        left_panel.setMaximumWidth(320)
        left_layout = QVBoxLayout(left_panel)

        # Группа "Электролит"
        group_electrolyte = QGroupBox("Параметры электролита")
        grid1 = QVBoxLayout(group_electrolyte)

        # Заряд катиона
        lbl_zc = QLabel("Заряд катиона (z+):")
        self.input_zc = QLineEdit("1")
        grid1.addWidget(lbl_zc)
        grid1.addWidget(self.input_zc)

        # Заряд аниона
        lbl_za = QLabel("Заряд аниона (z-):")
        self.input_za = QLineEdit("-1")
        grid1.addWidget(lbl_za)
        grid1.addWidget(self.input_za)

        # Концентрация
        lbl_conc = QLabel("Концентрация (моль/л):")
        self.input_conc = QLineEdit("0.1")
        grid1.addWidget(lbl_conc)
        grid1.addWidget(self.input_conc)

        left_layout.addWidget(group_electrolyte)

        # Группа "Модель"
        group_model = QGroupBox("Параметры модели")
        grid2 = QVBoxLayout(group_model)

        # Радиокнопки
        self.radio_group = QButtonGroup()
        self.radio_first = QRadioButton("Первое приближение")
        self.radio_second = QRadioButton("Второе приближение")
        self.radio_third = QRadioButton("Третье приближение")
        self.radio_third.setChecked(True)  # по умолчанию активно третье

        self.radio_group.addButton(self.radio_first, 1)
        self.radio_group.addButton(self.radio_second, 2)
        self.radio_group.addButton(self.radio_third, 3)

        grid2.addWidget(self.radio_first)
        grid2.addWidget(self.radio_second)
        grid2.addWidget(self.radio_third)

        # Поле a (активно для 2 и 3)
        lbl_a = QLabel("Эффективный диаметр a (Å):")
        self.input_a = QLineEdit("4.0")
        grid2.addWidget(lbl_a)
        grid2.addWidget(self.input_a)

        # Поле C (активно только для 3)
        lbl_c = QLabel("Эмпирический коэффициент C:")
        self.input_c = QLineEdit("0.1")
        grid2.addWidget(lbl_c)
        grid2.addWidget(self.input_c)

        # Подключаем сигналы для блокировки полей
        self.radio_first.toggled.connect(self.update_fields_state)
        self.radio_second.toggled.connect(self.update_fields_state)
        self.radio_third.toggled.connect(self.update_fields_state)

        left_layout.addWidget(group_model)

        # Кнопка расчета
        self.btn_calculate = QPushButton("Рассчитать и построить")
        self.btn_calculate.clicked.connect(self.calculate_and_plot)
        left_layout.addWidget(self.btn_calculate)

        # Группа "Результаты"
        group_results = QGroupBox("Результаты для заданной точки")
        grid3 = QVBoxLayout(group_results)

        self.lbl_I = QLabel("Ионная сила I: -")
        self.lbl_lg1 = QLabel("lg(γ±) 1-е прибл.: -")
        self.lbl_lg2 = QLabel("lg(γ±) 2-е прибл.: -")
        self.lbl_lg3 = QLabel("lg(γ±) 3-е прибл.: -")

        grid3.addWidget(self.lbl_I)
        grid3.addWidget(self.lbl_lg1)
        grid3.addWidget(self.lbl_lg2)
        grid3.addWidget(self.lbl_lg3)
        left_layout.addWidget(group_results)

        # Заглушка для автоподбора
        self.btn_auto = QPushButton("Автоподбор параметров (в разработке)")
        self.btn_auto.setEnabled(False)
        left_layout.addWidget(self.btn_auto)

        # Растягивающийся спейсер
        left_layout.addStretch()

        # ==================== ПРАВАЯ ПАНЕЛЬ (ГРАФИК) ====================
        self.canvas = MplCanvas(self, width=8, height=6, dpi=100)

        # Добавляем панели в главный лейаут
        main_layout.addWidget(left_panel)
        main_layout.addWidget(self.canvas, 1)  # 1 - stretch factor

    def update_fields_state(self):
        """Блокировка/разблокировка полей ввода в зависимости от выбранного приближения."""
        if self.radio_first.isChecked():
            self.input_a.setEnabled(False)
            self.input_c.setEnabled(False)
        elif self.radio_second.isChecked():
            self.input_a.setEnabled(True)
            self.input_c.setEnabled(False)
        else:
            self.input_a.setEnabled(True)
            self.input_c.setEnabled(True)

    def calculate_and_plot(self):
        """Основная логика: парсинг, расчет, обновление графика и результатов."""
        try:
            # 1. Парсинг ввода
            z_c = int(self.input_zc.text())
            z_a = int(self.input_za.text())
            conc = float(self.input_conc.text())
            a_val = float(self.input_a.text()) if self.input_a.isEnabled() else 4.0
            c_val = float(self.input_c.text()) if self.input_c.isEnabled() else 0.0

            if conc <= 0:
                raise ValueError("Концентрация должна быть положительной.")
            if a_val <= 0:
                raise ValueError("Параметр a должен быть положительным.")

            # 2. Расчет ионной силы для введенной концентрации
            I_point = DebyeHuckelModel.ionic_strength(z_c, z_a, conc)

            # 3. Расчет значений в точке
            lg1_point = DebyeHuckelModel.first_approx(z_c, z_a, I_point)
            lg2_point = DebyeHuckelModel.second_approx(z_c, z_a, I_point, a_val)
            lg3_point = DebyeHuckelModel.third_approx(z_c, z_a, I_point, a_val, c_val)

            # 4. Обновление текстовых результатов
            self.lbl_I.setText(f"Ионная сила I: {I_point:.4f} моль/л")
            self.lbl_lg1.setText(f"lg(γ±) 1-е прибл.: {lg1_point:.4f}")
            self.lbl_lg2.setText(f"lg(γ±) 2-е прибл.: {lg2_point:.4f}")
            self.lbl_lg3.setText(f"lg(γ±) 3-е прибл.: {lg3_point:.4f}")

            # 5. Генерация данных для плавных кривых
            # Диапазон sqrt(I) строим от 0 до sqrt(I_max), где I_max = 0.5 (с запасом)
            sqrt_I_max = max(np.sqrt(I_point) * 1.2, 0.7)
            sqrt_I_range = np.linspace(0, sqrt_I_max, 100)
            I_range = sqrt_I_range**2

            lg1_curve = DebyeHuckelModel.first_approx(z_c, z_a, I_range)
            lg2_curve = DebyeHuckelModel.second_approx(z_c, z_a, I_range, a_val)
            lg3_curve = DebyeHuckelModel.third_approx(z_c, z_a, I_range, a_val, c_val)

            # 6. Построение графика
            self.canvas.axes.clear()

            # Теоретические кривые
            self.canvas.axes.plot(sqrt_I_range, lg1_curve, 'k--', label='1-е прибл. (Предельный закон)')
            self.canvas.axes.plot(sqrt_I_range, lg2_curve, 'b-.', label='2-е прибл. (Расширенный)')
            self.canvas.axes.plot(sqrt_I_range, lg3_curve, 'r-', label='3-е прибл. (С поправкой)')

            # Экспериментальные точки
            if self.exp_x is not None and self.exp_y is not None:
                self.canvas.axes.scatter(self.exp_x, self.exp_y, c='green', marker='o',
                                       label='Эксперимент', zorder=5)

            # Вертикальная линия текущей концентрации и точка на активной кривой
            sqrt_I_point = np.sqrt(I_point)
            if self.radio_first.isChecked():
                active_y = lg1_point
            elif self.radio_second.isChecked():
                active_y = lg2_point
            else:
                active_y = lg3_point

            self.canvas.axes.axvline(x=sqrt_I_point, color='gray', linestyle=':', alpha=0.7)
            self.canvas.axes.plot(sqrt_I_point, active_y, 'o', color='red', markersize=8, zorder=6)

            # Оформление
            self.canvas.axes.set_xlabel("√I (моль/л)^(1/2)")
            self.canvas.axes.set_ylabel("lg(γ±)")
            self.canvas.axes.grid(True, linestyle='--', alpha=0.7)
            self.canvas.axes.legend()
            self.canvas.axes.set_title(f"Электролит: z+={z_c}, z-={z_a}, c={conc} моль/л")

            self.canvas.fig.tight_layout()
            self.canvas.draw()

            self.statusBar.showMessage("Расчет выполнен успешно.")

        except ValueError as e:
            QMessageBox.critical(self, "Ошибка ввода", str(e))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Произошла непредвиденная ошибка: {e}")

    def load_csv(self):
        """Загрузка экспериментальных данных из CSV."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Открыть CSV с данными", "", "CSV Files (*.csv)"
        )
        if not file_path:
            return

        try:
            data = np.genfromtxt(file_path, delimiter=',', skip_header=1)
            self.exp_x = data[:, 0]  # sqrt(I)
            self.exp_y = data[:, 1]  # lg(gamma)
            self.statusBar.showMessage(f"Загружено {len(self.exp_x)} точек из {os.path.basename(file_path)}")
            # Перерисовываем график, если он уже есть
            self.calculate_and_plot()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка загрузки", f"Не удалось прочитать файл: {e}")

    def save_png(self):
        """Сохранение графика в PNG."""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить график", "debye_huckel_plot.png", "PNG Files (*.png)"
        )
        if file_path:
            self.canvas.fig.savefig(file_path, dpi=300)
            self.statusBar.showMessage(f"График сохранен: {file_path}")

    def save_csv(self):
        """Сохранение результатов в CSV."""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить таблицу", "results.csv", "CSV Files (*.csv)"
        )
        if not file_path:
            return

        try:
            # Генерируем данные для экспорта (берем текущие настройки)
            z_c = int(self.input_zc.text())
            z_a = int(self.input_za.text())
            a_val = float(self.input_a.text()) if self.input_a.isEnabled() else 4.0
            c_val = float(self.input_c.text()) if self.input_c.isEnabled() else 0.0

            sqrt_I_range = np.linspace(0, 0.7, 100)
            I_range = sqrt_I_range**2

            lg1 = DebyeHuckelModel.first_approx(z_c, z_a, I_range)
            lg2 = DebyeHuckelModel.second_approx(z_c, z_a, I_range, a_val)
            lg3 = DebyeHuckelModel.third_approx(z_c, z_a, I_range, a_val, c_val)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write("sqrt(I),I,lg_gamma_1,lg_gamma_2,lg_gamma_3\n")
                for i in range(len(sqrt_I_range)):
                    f.write(f"{sqrt_I_range[i]:.4f},{I_range[i]:.4f},{lg1[i]:.6f},{lg2[i]:.6f},{lg3[i]:.6f}\n")

            self.statusBar.showMessage(f"Таблица сохранена: {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка сохранения", str(e))

    def save_pdf(self):
        """Экспорт отчета в PDF."""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить отчет", "report.pdf", "PDF Files (*.pdf)"
        )
        if not file_path:
            return

        try:
            from reportlab.lib.utils import ImageReader
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont

            # === РЕГИСТРАЦИЯ ШРИФТА С ПОДДЕРЖКОЙ КИРИЛЛИЦЫ ===
            try:
                # Пробуем Arial (Windows)
                pdfmetrics.registerFont(TTFont('Arial', 'Arial.ttf'))
                pdfmetrics.registerFont(TTFont('Arial-Bold', 'Arialbd.ttf'))
                font_name = 'Arial'
                font_name_bold = 'Arial-Bold'
            except:
                try:
                    # Пробуем DejaVu Sans (Linux / универсальный)
                    pdfmetrics.registerFont(TTFont('DejaVuSans', 'DejaVuSans.ttf'))
                    pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', 'DejaVuSans-Bold.ttf'))
                    font_name = 'DejaVuSans'
                    font_name_bold = 'DejaVuSans-Bold'
                except:
                    # Если ничего не нашлось — Courier (моноширинный, но с кириллицей)
                    font_name = 'Courier'
                    font_name_bold = 'Courier-Bold'

            # Создаем PDF
            c = canvas.Canvas(file_path, pagesize=A4)
            width, height = A4

            # Заголовок
            c.setFont(font_name_bold, 16)
            c.drawString(2*cm, height - 2*cm, "Debye-Huckel Analyzer - Отчет")
            c.setFont(font_name, 12)
            c.drawString(2*cm, height - 2.5*cm, f"Дата: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')}")

            # Параметры расчета
            z_c = self.input_zc.text()
            z_a = self.input_za.text()
            conc = self.input_conc.text()
            a_val = self.input_a.text() if self.input_a.isEnabled() else "N/A"
            c_val = self.input_c.text() if self.input_c.isEnabled() else "N/A"

            y_pos = height - 3.5*cm
            c.setFont(font_name_bold, 14)
            c.drawString(2*cm, y_pos, "Параметры расчета:")
            c.setFont(font_name, 12)
            params = [
                f"Заряд катиона: {z_c}",
                f"Заряд аниона: {z_a}",
                f"Концентрация: {conc} моль/л",
                f"Параметр a: {a_val} Å",
                f"Параметр C: {c_val}"
            ]
            for param in params:
                y_pos -= 0.7*cm
                c.drawString(2.5*cm, y_pos, param)

            # Результаты в точке
            y_pos -= 1.5*cm
            c.setFont(font_name_bold, 14)
            c.drawString(2*cm, y_pos, "Результаты в заданной точке:")
            c.setFont(font_name, 12)
            results = [
                self.lbl_I.text(),
                self.lbl_lg1.text(),
                self.lbl_lg2.text(),
                self.lbl_lg3.text()
            ]
            for res in results:
                y_pos -= 0.7*cm
                c.drawString(2.5*cm, y_pos, res)

            # Сохраняем временный PNG график и вставляем в PDF
            img_data = BytesIO()
            self.canvas.fig.savefig(img_data, format='png', dpi=150)
            img_data.seek(0)

            # Правильный способ для новых версий reportlab
            img_reader = ImageReader(img_data)

            # Вставка изображения
            y_img = y_pos - 1*cm
            img_height = 12*cm
            if y_img - img_height < 1*cm:
                c.showPage()
                y_img = height - 2*cm
            c.drawImage(img_reader, 2*cm, y_img - img_height, width=14*cm, height=img_height)

            c.save()
            self.statusBar.showMessage(f"Отчет сохранен: {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка создания PDF", str(e))

    def show_about(self):
        QMessageBox.about(self, "О программе",
            "Debye-Huckel Analyzer v.1.0\n\n"
            "Программа для моделирования коэффициентов активности\n"
            "электролитов по трем приближениям теории Дебая-Хюккеля.\n\n"
            "Разработчик: [Черников Николай Дмитриевич]\n"
            "Язык: Python 3.14.6, PySide6, Matplotlib\n\n"
        )

# ============================================================
# 4. ТОЧКА ВХОДА
# ============================================================
if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Стилизация
    app.setStyle('Fusion')
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())